#include "colores.h"

// Colores

void red(){
  printf("\033[1;31m");
}

void green(){
  printf("\033[0;32m");
}

void white(){
  printf("\033[0;37m");
}

void yellow(){
  printf("\033[0;33m");
}
