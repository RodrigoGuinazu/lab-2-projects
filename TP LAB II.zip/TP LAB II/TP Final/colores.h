#ifndef COLORES_H_INCLUDED
#define COLORES_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>

void red();
void green();
void white();
void yellow();

#endif // COLORES_H_INCLUDED
